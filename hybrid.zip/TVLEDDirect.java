class TVLEDDirect extends TVLED{
int color = 10;
int contras = 10;
   public void pengaturanColor(int ecolor){
	color = ecolor);
   }
   public void pengaturanContras(int econtras){
	contras = econtras);
   }
}