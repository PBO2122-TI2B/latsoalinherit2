class TV{
boolean status = false;
int chanel = 0;
   public void statusOn(){
	status = true;
   }
   public void statusOff(){
	status = false;
   }
   public void gantiChanel(int echanel){
	chanel = echanel;
   }
}

