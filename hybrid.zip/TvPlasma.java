class TvPlasma extends TV
{
int kecerahan = 10;
   public void tambahKecerahan(int ekecerahan){
	kecerahan += ekecerahan;
   }
   public void kurangiKecerahan(int ekecerahan){
	kecerahan -= ekecerahan;
   }
}