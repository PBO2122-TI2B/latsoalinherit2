public class Mamalia{
    String nama;
    String keterangan;

    Mamalia(String nm, String ket){
        this.nama = nm;
        this.keterangan = ket;
    }

    public void Cetak(){
        System.out.println("Nama Kelas : " +nama);
        System.out.println("Keterangan : " +keterangan);
    }
}

//Adika Ahmad Hanif Nazhir