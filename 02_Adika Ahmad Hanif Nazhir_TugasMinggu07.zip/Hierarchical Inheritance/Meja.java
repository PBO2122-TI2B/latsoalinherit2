public class Meja extends Kayu {
    String bentuk = "Persegi";

    public void cetakMeja(){
        System.out.println("Model Kayu  : Meja");
        System.out.println("Bentuk Meja : " +bentuk);
    }
}

//Adika Ahmad Hanif Nazhir