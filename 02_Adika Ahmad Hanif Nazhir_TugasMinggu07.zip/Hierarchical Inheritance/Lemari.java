public class Lemari extends Kayu {
    String kegunaan = "Menyimpan Baju";

    public void cetakLemari(){
        System.out.println("Model Kayu      : Lemari");
        System.out.println("Fungsi Lemari   : " +kegunaan);
    }
}

//Adika Ahmad Hanif Nazhir