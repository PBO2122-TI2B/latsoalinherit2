public class Kayu{
    public String jenis = "Jati";

    public void cetak(){
        System.out.println(" Kayu ");
        System.out.println("Jenis Kayu : " +jenis);
    }
}

//Adika Ahmad Hanif Nazhir