public class Kursi extends Kayu {
    String kegunaan = "Duduk / Istirahat";

    public void cetakKursi(){
        System.out.println("Model Kayu      : Kursi");
        System.out.println("Fungsi Kursi    : " +kegunaan);
    }
}

//Adika Ahmad Hanif Nazhir