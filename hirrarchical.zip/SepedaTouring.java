class SepedaTouring extends Sepeda{
boolean light = false;
  public void lightOn(){
     light = true;
  }
  public void lightOff(){
     light = false;
  }
}
