class SepedaListrik extends Sepeda{
booolean mesin = false;
  public void mesinOn(){
     mesin = true;
  }
  public void mesinOff(){
     mesin = false;
  }
}
