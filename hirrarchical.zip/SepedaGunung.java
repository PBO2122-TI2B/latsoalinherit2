class SepedaGunung extends A{
int gir = 1;
   public void gantiGir(int egir){
      gir = egir;
   }
}
