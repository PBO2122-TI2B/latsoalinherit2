class Sepeda{
int kecepatan = 0;
   public void tambahKecepatan(int ekecepatan){
      kecepatan += ekecepatan;
   }
   public void kurangiKecepatan(int ekecepatan){
      kecepatan -= ekecepatan;;
   }
   public void rem(){
      kecepatan =0;
   }
}
