package Hierarchical;
public class Mobil extends Transportasi{
    void roda(){
        System.out.println("Mobil adalah Kendaraan Roda Empat");
    }
}
