package Hierarchical;
public class Kapal extends Transportasi{
    void tenaga(){
        System.out.println("Kapal dengan tenaga penggerak motor atau diesel");
    }
}
