package Hierarchical;
public class Pesawat extends Transportasi{
    void propulsi(){
        System.out.println("Propulsi Pewasat adalah Pesawat Terbang Layang");
    }
}
