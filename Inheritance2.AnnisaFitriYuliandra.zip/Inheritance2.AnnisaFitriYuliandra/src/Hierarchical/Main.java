package Hierarchical;
public class Main {
    public static void main(String[] args) {
        Mobil m = new Mobil();
        m.roda(); m.darat(); m.fungsi();
        Kapal k = new Kapal();
        k.tenaga(); k.air(); k.fungsi();
        Pesawat p = new Pesawat();
        p.propulsi(); p.udara(); p.fungsi();
    }
}
