package Hierarchical;
public class Transportasi {
    void fungsi(){
        System.out.println("Fungsi    : Membantu perpindahan arus manusia dan barang ke berbagai wilayah.");
    }
    void darat(){
        System.out.println("Jenis     : Transportasi Darat");
    }
    void air(){
        System.out.println("Jenis     : Transportasi Air");
    }
    void udara(){
        System.out.println("Jenis     : Transportasi Darat");
    }
}
