package Hybrid;
public class Motor extends RodaDua{
    void kapasitasPenumpang(){
        System.out.println("Motor");
        System.out.println("Kapasitas Penumpang adalah 2 orang.");
    }
}
