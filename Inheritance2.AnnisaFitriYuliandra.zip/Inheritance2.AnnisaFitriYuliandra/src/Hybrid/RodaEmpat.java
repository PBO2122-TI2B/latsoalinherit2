package Hybrid;
public class RodaEmpat extends Kendaraan{
    void tipe(){
        System.out.println("Tipe      : Kendaraan Roda Empat");
    }
}
