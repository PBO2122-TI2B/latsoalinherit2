package Hybrid;
public class Main {
    public static void main(String[] args) {
        Motor m = new Motor();
        m.kapasitasPenumpang(); m.tipe(); m.fungsi();
    }
}
