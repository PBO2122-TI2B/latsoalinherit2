package Hybrid;
public class Kendaraan {
    void fungsi(){
        System.out.println("Fungsi    : Membantu perpindahan arus manusia dan barang ke berbagai wilayah.");
        System.out.println("Jenis     : Transportasi Darat");
    }
}
