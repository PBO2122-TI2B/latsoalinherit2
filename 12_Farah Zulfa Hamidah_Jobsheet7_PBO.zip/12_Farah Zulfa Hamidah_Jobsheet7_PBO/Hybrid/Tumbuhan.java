package Hybrid;

public class Tumbuhan {
    String ID, namaTumbuhan, keterangan, jenis;
 
    public void ID(){
    }
 
    public void namaTumbuhan(){
    }
 
    public void keterangan(){
    }
 
    public void jenis(){
    }
 
    public void cetakdata(){
    }
}
