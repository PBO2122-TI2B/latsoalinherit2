package Inheritance2.Hybrid;

public class Handphone extends Komputer{

    public void aturUkuranLayar(int inch){
        System.out.println("Ukuran Layar Handphone Adalah: " + inch + " inch");
    }

}
