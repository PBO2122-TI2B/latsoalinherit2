package Inheritance2.Hybrid;

public class Windows extends Laptop{

    public void tambahFitur(String fitur){
        System.out.println("Fitur windows terbaru adalah " + fitur);
    }
}
