package Inheritance2.Hybrid;

public class Komputer {
    String merk;
    int sizeMemory;
    String processor;

    public void tampilData(){
        System.out.println("Merk: " + merk);
        System.out.println("Kapasitas Memory: " + sizeMemory);
        System.out.println("Processor: " + processor);
    }
}
