package Inheritance2.Hybrid;

public class Laptop extends Komputer{

    public void aturKapasitasBaterai(int jmlh){
        System.out.println("Jumlah Kapasitas Baterai Adalah: " + jmlh);
    }

}
