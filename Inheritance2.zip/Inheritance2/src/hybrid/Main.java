/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hybrid;

/**
 *
 * @author LENOVO
 */
public class Main {
    public static void main(String args[]) {
	kelas4 D = new kelas4();
        kelas3 C = new kelas3();
        kelas2 B = new kelas2();
        
	D.d();
        C.c();
        B.b();
   }
}
