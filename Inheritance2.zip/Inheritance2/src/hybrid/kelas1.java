/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hybrid;

/**
 *
 * @author LENOVO
 */
public class kelas1 {
    public void a() {
       	System.out.println("Jumlah Kelas 1 : A-C");
    }
}
