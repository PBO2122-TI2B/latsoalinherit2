package Inheritance2.Hierarchical;

public class MobilC extends Mobil{
    int kapasitas;

    public void aturKapasitasMobil(){
        System.out.println("Kapasitas mobil adalah " + kapasitas);
    }
}
