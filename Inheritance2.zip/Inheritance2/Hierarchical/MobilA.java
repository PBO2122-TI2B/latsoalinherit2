package Inheritance2.Hierarchical;

public class MobilA extends Mobil{
    String warna;

    public void gantiWarnaMobil(){
        System.out.println("Warna Mobil adalah " + warna);
    }
}
