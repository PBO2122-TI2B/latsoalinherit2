package Inheritance2.Hierarchical;

public class MobilB extends Mobil{
    int aturTangki;

    public void aturTangkiMobil(){
        System.out.println("BMW memiliki Max Tangki " + aturTangki);
    }
}
