/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HybridInheritance;

/**
 *
 * @author Asus X453
 */
public class AnakPerempuan extends Ayah{
        public AnakPerempuan() {
		System.out.println("anak Perempuan...");
	}

	public void Tas() {
		System.out.println("Tas milik anak Perempuan");
	}
}
