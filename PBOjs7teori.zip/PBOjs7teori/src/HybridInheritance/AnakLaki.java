/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HybridInheritance;

/**
 *
 * @author Asus X453
 */
public class AnakLaki extends Ayah{
    public AnakLaki() {
		System.out.println("anak laki laki...");
	}

	public void Handphone() {
		System.out.println("Handphone milik anak laki laki");
	}
}

