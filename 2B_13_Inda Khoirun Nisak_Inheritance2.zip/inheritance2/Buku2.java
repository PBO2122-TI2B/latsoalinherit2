package inheritance2;

public class Buku2 {
    private int jumlahHalaman;

    public void setJumlahHalaman(int newValue) {
        jumlahHalaman = newValue;
    }

    public int getJumlahHalaman() {
        return jumlahHalaman;
    }
}
