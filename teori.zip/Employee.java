/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jti.polinema.inheritance2.teori;
/**
 * Nama      : Rofika Nur 'Aini
 * NIM       : 2041720099
 * No. Absen : 24
 * Kelas     : 2B
 **/
public class Employee {
    double salary = 50000;
 
    void displaySalary() {
        System.out.println("Employee Salary: "+salary+" IDR");
    }
}
