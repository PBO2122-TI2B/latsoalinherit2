public class Toyota extends Mobil
{
   public void disp()
   {
	System.out.println("Kijang Inova Reborn");
   }
}