public class Motor{
   public void methodMotor()
   {
      System.out.println("Jenis Jenis Motor :");
   }
}