public class Honda extends Motor
{
  public void methodHonda()
  {
     System.out.println("PCX 160 NEW");
  }
}