public class Kawasaki extends Motor
{
  public void methodKawasaki()
  {
     System.out.println("ZX25-R 4 Cylinder");
  }
}