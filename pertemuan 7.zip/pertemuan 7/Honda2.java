public class Honda2 extends Mobil
{
   public void disp()
   {
	System.out.println("Civic Type R");
   }
	
}