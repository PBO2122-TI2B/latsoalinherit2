public class Mobil
{
   public void disp()
   {
	System.out.println("Merek Mobil");
   }
}