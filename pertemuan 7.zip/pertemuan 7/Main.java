public class Main
{
  public static void main(String args[])
  {
     Yamaha obj1 = new Yamaha();
     Honda obj2 = new Honda();
     Kawasaki obj3 = new Kawasaki();
   
     obj1.methodYamaha();
     obj2.methodHonda();
     obj3.methodKawasaki();
  }
}