public class Mitshubisi extends Toyota
{
   public void disp()
   {
	System.out.println("Pajero Sport");
   }
	
}