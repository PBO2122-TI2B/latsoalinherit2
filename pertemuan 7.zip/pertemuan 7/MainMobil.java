public class MainMobil{
   public static void main(String args[]){

	Mitshubisi obj = new Mitshubisi();
	obj.disp();
   }
}