public class Yamaha extends Motor
{
   public void methodYamaha()
   {
      System.out.println("Aerox 155 Conected");
   }
}