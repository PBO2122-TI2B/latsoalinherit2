package Hierarchical;

public class Dogs extends Animals{
    
    public void bark() {
        
    }
}
