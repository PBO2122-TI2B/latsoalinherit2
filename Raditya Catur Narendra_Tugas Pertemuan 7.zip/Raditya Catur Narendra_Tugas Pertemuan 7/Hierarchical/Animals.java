package Hierarchical;

public class Animals {
    public String kelasVertebrata;

    public void eat() {
        
    }

    public void breathe() {

    }
}
