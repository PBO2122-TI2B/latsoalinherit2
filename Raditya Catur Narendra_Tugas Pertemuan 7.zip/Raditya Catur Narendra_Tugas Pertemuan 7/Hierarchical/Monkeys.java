package Hierarchical;

public class Monkeys extends Animals{
    
    public void swing() {

    }
}
