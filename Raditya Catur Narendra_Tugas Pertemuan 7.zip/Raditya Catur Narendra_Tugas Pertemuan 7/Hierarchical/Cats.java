package Hierarchical;

public class Cats extends Animals{
    
    public void meow() {

    }
}
