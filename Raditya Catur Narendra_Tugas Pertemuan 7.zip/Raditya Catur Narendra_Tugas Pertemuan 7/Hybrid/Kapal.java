package Hybrid;

public class Kapal extends KendaraanLaut{
    public String merk;
}
