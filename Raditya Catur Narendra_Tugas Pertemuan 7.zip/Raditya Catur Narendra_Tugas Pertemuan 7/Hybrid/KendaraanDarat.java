package Hybrid;

public class KendaraanDarat extends KendaraanMesin{
    public int jumlahRoda;
}
