package Hybrid;

public class KendaraanLaut extends KendaraanMesin{
    public double besarLayar;
}
