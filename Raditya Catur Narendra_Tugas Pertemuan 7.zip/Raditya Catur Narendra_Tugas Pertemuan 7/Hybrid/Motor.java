package Hybrid;

public class Motor extends KendaraanDarat
    public String merk;
}
