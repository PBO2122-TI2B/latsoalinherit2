package Hybrid;

public class Mobil extends KendaraanDarat{
    public String merk;
}
